package com.simpleform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
