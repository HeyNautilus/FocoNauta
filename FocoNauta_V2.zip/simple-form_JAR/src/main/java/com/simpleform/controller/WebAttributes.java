package com.simpleform.controller;

public class WebAttributes {

    public static final String AUTHENTICATION_EXCEPTION = null;

}
